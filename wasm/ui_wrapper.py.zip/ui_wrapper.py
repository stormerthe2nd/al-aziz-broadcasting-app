"""ui_wrapper_python_code

    Metadata:-
        Version   - v1.1.0
        Last mod  - 2023-03-27T11:24:33.776695+05:30 (ISO8601 format)

    ------------------------------------------

    Functions:-
        - Calculate updated Breakeven & pnl data by Black Scholes model based on underlying & days to expiry

    ------------------------------------------

    Version Change Logs:-
        
    v1.1.0
        - Add separate mode ('get_black_schole_ltp') for Black Scholes model

    ------------------------------------------

    External Libraries:-
        -

    ------------------------------------------

    TODO:-
        - 

    ------------------------------------------
"""

# ----------------------------------------------------------------------------

# region Imports

# Built-in Imports
import json
import math
import traceback
import statistics

from typing import Union, Literal
from dataclasses import dataclass

# endregion

# region Global Variables

ALLOWED_MODES = {
    'zb': {
        'get_chart_data',  # sub mode
    },
    'get_black_schole_ltp': {},
}

# endregion

# ----------------------------------------------------------------------------


def get_main_data(event: dict[str]) -> str:
    """
        Main entry point of UI

        Receive request from UI and process it, then return response in json string
    """

    try:
        final_resp = EventProcessor(event).get_data()

    except Exception:
        final_resp = {
            'status': 0,
            'msg': json.dumps(traceback.format_exc())
        }

    finally:
        return json.dumps(final_resp)

# ----------------------------------------------------------------------------


class EventProcessor:

    def __init__(self, event: dict[str]) -> None:
        # UI facing some issue on sending some data type like map object, so receiving data via json string
        self.event = json.loads(event)

    # -------------------------------------------------

    def get_data(self) -> dict[str]:
        """Route to requested function and return the response"""

        if (mode := self.event.get('mode')) not in ALLOWED_MODES:
            return {
                'status': 0,
                'msg': f"Invalid mode -> {mode}"
            }

        elif mode == 'zb':
            return ZB(self.event).get_data()

        elif mode == 'get_black_schole_ltp':
            return self._get_projected_ltp()

    # -------------------------------------------------

    def _get_projected_ltp(self):
        """Project the ltp using Black-Scholes model and return it"""

        projected_ltp = ProjectedData(
            iv=self.event['iv'],
            opt_typ=self.event['opt_typ'],
        ).get_projected_ltp(
            spot_price=self.event['underlying'],
            target_strike=self.event['strike'],
            diff_days=self.event['diff_days'],
        )

        return {
            'status': 1,
            'projected_ltp': projected_ltp,
        }

# ----------------------------------------------------------------------------


@dataclass
class ZB:

    event: dict[str]

    # -------------------------------------------------

    def get_data(self) -> dict[str]:
        """
            Return the updated breakeven & PNL data

            Sample event
            {
                'mode': 'zb',
                'sub_mode': 'get_chart_data',
            }
        """

        if (sub_mode := self.event.get('sub_mode')) not in ALLOWED_MODES[self.event['mode']]:
            return {
                'status': 0,
                'msg': f"Invalid sub_mode -> {sub_mode}"
            }

        elif sub_mode == 'get_chart_data':
            return {
                'status': 1,
                'data': self.get_chart_data(),
            }

    # -------------------------------------------------

    def get_chart_data(self) -> dict[str]:
        """
            Return the updated breakeven & PNL data

            Sample event
            {
                'mode': 'zb',
                'sub_mode': 'get_chart_data',
                'all_strike_data': [17200, 17250, 17300, 17350],
                'diff_days': 2,
                'strategy_data': {
                    'iv': 0.1234,
                    'strike': 17300,
                    'ltp': 203.5,
                    'opt_type': 'c',
                },
                'lot_size': 50,
                'underlying_price': 17320.5,
                'is_breakeven_need': False,
                'is_chart_data_need': False,
                'get_expiry_data_too': False,
            }



            Parameters
            ----------
                Both positional arguments and keyword arguments are allowed

            a) all_strike_data : array[int | float]
                [strike_1, strike_2, ...]

            b) diff_days : int | float
                Difference between the start considered for calc and the expiry

            c) strategy_data - json string
                The strategy data for which the pnl chart data needs to be calculated.
                It contains the following data in map object

                iv - float (without multiply with 100!)
                ltp - float
                strike - int | float
                opt_type - Literal['c', 'p']

                Example - "{'iv': 0.1543, 'ltp': 123.4, 'strike': 17500, 'opt_type': 'c'}"

            d) Lot size - int
                Lot size of the symbol

            e) underlying_price - float
                Fair/Future price of the symbol


            Return
            ------
            a) breakeven value : float

            b) pnl_data : array[array]
                [[strike_1, pnl_1], [strike_2, pnl_2], ...]

            All the above values are dumps using json string

            Example - "{'breakeven': 17342.5, 'pnl_data': [[17500, 234.5], [17550, 123.4]]}"
        """

        target_date_resp = PnlData(self.event).get_data()

        final_resp = {
            'target_date': target_date_resp,
        }

        if self.event.get('get_expiry_data_too'):

            # If target date is expiry, don't need to calculate expiry data again
            if self.event['diff_days'] == 0:
                expiry_date_resp = target_date_resp
            else:
                expiry_date_resp = PnlData(self.event).get_data(force_diff_days=0)

            final_resp['expiry'] = expiry_date_resp

        return final_resp


# ----------------------------------------------------------------------------


@dataclass
class PnlData:

    event: dict[str]

    # -------------------------------------------------

    def get_data(self, force_diff_days: int = None) -> dict[str]:
        """
            Return the updated breakeven & PNL data

            Sample event
            {
                'all_strike_data': [17200, 17250, 17300, 17350],
                'diff_days': 2,
                'strategy_data': {
                    'iv': 0.1234,
                    'strike': 17300,
                    'ltp': 203.5,
                    'opt_type': 'c',
                },
                'lot_size': 50,
                'underlying_price': 17320.5,
                'is_breakeven_need': False,
                'is_chart_data_need': False,
            }
        """

        projected_data_obj = ProjectedData(self.event['strategy_data']['iv'], self.event['strategy_data']['opt_type'])

        pnl_data = {}

        is_breakeven_need = self.event.get('is_breakeven_need')
        is_chart_data_need = self.event.get('is_chart_data_need')

        if force_diff_days is not None:
            diff_days_ = force_diff_days
        else:
            diff_days_ = self.event['diff_days']

        for idx_, curr_strike in enumerate(self.event['all_strike_data']):

            projected_ltp = projected_data_obj.get_projected_ltp(
                spot_price=curr_strike,
                target_strike=self.event['strategy_data']['strike'],
                diff_days=diff_days_,
            )
            spot_mtm = int((projected_ltp-self.event['strategy_data']['ltp'])*self.event['lot_size'])

            pnl_data[curr_strike] = spot_mtm

            # checks if pnl is changing signs
            if is_breakeven_need:
                if (
                    idx_ != 0
                    and (spot_mtm * prev_spot_mtm) < 0
                ):
                    breakeven_found = False
                    if (spot_mtm != 0) and (prev_spot_mtm != 0):
                        # linear interpolation
                        breakeven = curr_strike - spot_mtm * (prev_strike - curr_strike) / (prev_spot_mtm - spot_mtm)
                        breakeven = self._precision_adjust(breakeven, self.event['underlying_price'])
                        breakeven_found = True

                    elif spot_mtm == 0:
                        breakeven = curr_strike
                        breakeven_found = True

                    if breakeven_found \
                            and not is_chart_data_need:
                        return {
                            'breakeven': breakeven,
                        }

                prev_spot_mtm = spot_mtm
                prev_strike = curr_strike

        # Sort pnl data by strikes
        pnl_data = [
            [strike, pnl_data[strike]]
            for strike in sorted(pnl_data)
        ]

        final_output = {
            'pnl_data': pnl_data,
        }

        if is_breakeven_need:
            final_output['breakeven'] = breakeven

        return final_output

    # -------------------------------------------------

    def _precision_adjust(self, val, udl):
        """return approximates value to nearest decimal based on underlying"""

        if udl >= 100:
            return round(val)
        elif 50 <= udl < 100:
            return round(2 * val) / 2
        elif 25 <= udl < 50:
            return round(4 * val) / 4
        else:
            return round(20 * val) / 20


# ----------------------------------------------------------------------------


@dataclass
class ProjectedData:

    iv: float
    opt_typ: Literal['c', 'p']

    # -------------------------------------------------

    def get_projected_ltp(self, spot_price: Union[int, float], target_strike: Union[int, float], diff_days: int) -> float:
        """Calculate projected price based on params"""

        if self.iv != 0 and diff_days > 0:
            return self._black_scholes_data(spot_price, target_strike, diff_days)

        if self.opt_typ == 'c':
            return max(spot_price - target_strike, 0)

        else:
            return max(target_strike - spot_price, 0)

    # -------------------------------------------------

    def _black_scholes_data(self, spot_price: Union[int, float], target_strike: Union[int, float], diff_days: int) -> float:
        """Return projected price based on Black-Scholes model formula"""

        time_to_mature = diff_days / 365

        d1 = (math.log(spot_price/target_strike) + ((self.iv**2)/2)*time_to_mature) / (self.iv*math.sqrt(time_to_mature))
        d2 = d1 - self.iv * math.sqrt(time_to_mature)

        if self.opt_typ == 'c':
            return (spot_price*self._get_cnd_value(d1)) - (target_strike*self._get_cnd_value(d2))

        elif self.opt_typ == 'p':
            return (target_strike*self._get_cnd_value(-d2)) - (spot_price*self._get_cnd_value(-d1))

    # -------------------------------------------------

    def _get_cnd_value(self, x: Union[int, float]) -> float:
        """Return Cumulative Normal Distribution value"""

        return statistics.NormalDist().cdf(x)

# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------
# ----------------------------------------------------------------------------

# # Sample request
# ----------------


if __name__ == '__main__':

    sample_event = {
        'mode': 'zb',
        'sub_mode': 'get_chart_data',
        'all_strike_data': list(range(16800, 17350, 50)),
        'diff_days': 2,
        'strategy_data': {
            'iv': 0.1662,
            'ltp': 103.55,
            'strike': 17000,
            'opt_type': 'c',
        },
        'lot_size': 50,
        'underlying_price': 17027.4,
        'is_breakeven_need': True,
        'is_chart_data_need': True,
        'get_expiry_data_too': True,
    }

    sample_event = {
        'mode': 'get_black_schole_ltp',
        'iv': 0.1662,
        'underlying': 17743,
        'strike': 17700,
        'diff_days': 1,
        'opt_typ': 'c',
    }

    sample_resp = get_main_data(json.dumps(sample_event))
    print(sample_resp)


# Sample Response
# ----------------

# # Success
# {
#     'status': 1,
#     'data': 'Json string data of respective modes'
# }

# # Failure
# {
#     'status': 0,
#     'msg': 'Error message for debugging'  # Don't show this message to USER!!! It meant only for debugging
# }
